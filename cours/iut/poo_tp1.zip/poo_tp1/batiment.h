#ifndef batiment_h
#define batiment_h

#include "zone.h"

#define MAXZONE 10

class Batiment
{
    private:
        Zone * tabZones[MAXZONE];

        int nbZones;


    public:
        // propriétés
        const int puissanceMax;

        // méthodes
        Batiment (int);
        ~Batiment ();

        Zone * getZone (string);

        bool ajouterZone (string, int, char);

        int consomation (void);
        int getNbZones ();

        void setNbZones (int);
        void afficher (void);
        void delester (void);
        void optimiser (void);

};

#endif



























