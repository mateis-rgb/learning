#include "batiment.h"

#include <iostream>
#include <string>

using namespace std;

Batiment::Batiment(int p) : puissanceMax(p)
{
    this->nbZones = 0;

    cout << "Batiment : appel du constructeur" << endl;
}


Batiment::~Batiment(void)
{
    for (int k = 0; k < this->nbZones; k++)
    {
        delete this->tabZones[k];
    }

    cout << "Batiment : appel du destructeur" << endl;
}


bool Batiment::ajouterZone(string nom, int conso, char priorite)
{
    if (this->nbZones >= MAXZONE) return false;

    Zone * zTemp = new Zone(nom, conso, priorite);

    this->tabZones[this->nbZones] = zTemp;

    this->nbZones++;

    return true;
}


void Batiment::afficher(void)
{
    for (int k = 0; k < this->nbZones; k++)
    {
        this->tabZones[k]->afficher();
    }
}


int Batiment::consomation(void)
{
    int conso = 0;

    for (int k = 0; k < this->nbZones; k++)
    {
        Zone * zTemp = this->tabZones[k];

        if (zTemp->getEtat() == STATE_ON) conso += zTemp->getConso();
    }

    return conso;
}


Zone * Batiment::getZone(string nom)
{
    for (int k = 0; k < this->nbZones; k++)
    {
        Zone * zTemp = this->tabZones[k];

        if (zTemp->getNom() == nom) return zTemp;
    }

    return NULL;
}


void Batiment::delester(void)
{
    for (int k = 0; k < this->nbZones; k++)
    {
        Zone * zTemp = this->tabZones[k];

        if (zTemp->getEtat() == STATE_ON)
        {
            zTemp->setEtat(STATE_DEL);
        }
    }
}


void Batiment::optimiser(void)
{
    for (int i = 0; i < 3; i++) {
        for (int k = 0; k < this->nbZones; k++)
        {
            Zone * zTemp = this->tabZones[k];
            int conso = this->consomation();

            if ((zTemp->getEtat() == STATE_DEL) && (zTemp->getPrio() == i))
            {
                if (conso + zTemp->getConso() <= this->puissanceMax)
                {
                    zTemp->setEtat(STATE_ON);
                }
            }
        }
    }
}


int Batiment::getNbZones()
{
    return this->nbZones;
}


void Batiment::setNbZones(int nbZones)
{
    this->nbZones = nbZones;
}













