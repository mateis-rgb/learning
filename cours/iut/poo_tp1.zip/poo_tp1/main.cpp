#include <iostream>

#include "batiment.h"

using namespace std;

int main(int argc, char *argv[])
{
    Batiment * pBati = new Batiment(50);

    string zones[5] = {"bain", "cuisine", "salle", "sejour", "bureau"};
    int consos[5] = {12, 45, 4, 21, 6};
    char priorites[5] = {0, 1, 2, 1, 0};

    for (int k = 0; k < 5; k++)
    {
        pBati->ajouterZone(zones[k], consos[k], priorites[k]);
    }

    pBati->afficher();
    pBati->optimiser();

    cout << "Conso totale : " << pBati->consomation() << endl;

    // activation zone
    bool fini = false;
    string nom = "";
    Zone * pZone;

    while (!fini)
    {
        cout << "Quelle zone voulez-vous activer ? (\"fin\" pour arreter) ";
        cin >> nom;

        if (nom != "fin")
        {
            pZone = pBati->getZone(nom);

            if (pZone != NULL)
            {
                pZone->setEtat(STATE_ON); // passe ON

                if (pBati->consomation() > pBati->puissanceMax)
                {
                    pBati->delester();
                    pBati->optimiser();
                }

                pBati->afficher();

                cout << "Conso totale : " << pBati->consomation() << endl;
            }
            else
            {
                cout << "[ERROR]: pas de zone existante pour le nom " << nom << endl;
            }
        }
        else
        {
            fini = true;
        }
    }

    delete pBati;

    return 0;
}





























