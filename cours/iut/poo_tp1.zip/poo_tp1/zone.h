#ifndef zone_h
#define zone_h

#include <string>

using namespace std;

#define STATE_OFF 0
#define STATE_DEL 1
#define STATE_ON 2

#define PRIO_HIGH 0
#define PRIO_MODERATE 1
#define PRIO_LOW 2

class Zone
{
    private:
        // propriétés
        string nom;

        int conso;

        char etat; // 0 = off; 1 = del; 1 = on;
        string tabetat[3] = {"OFF", "DEL", "ON"};

        char priorite; // 0 = high; 1 = moderate; 2 = low;
        string tabprio[3] = {"HIGH", "MODERATE", "LOW"};


    public:
        // méthodes
        Zone(string, int, char);

        int getConso(void);
        int getEtat(void);

        char getPrio (void);

        string getNom(void);

        void setEtat (int);
        void afficher (void);
};

#endif
