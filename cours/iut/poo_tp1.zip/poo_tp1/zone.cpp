#include <iostream>

#include "zone.h"


using namespace std;

Zone::Zone(string n, int c, char p) {
    this->nom = n;
    this->conso = c;
    this->priorite = p;

    this->etat = 0;

    cout << this->nom << " : appel du constructeur" << endl;
}

void Zone::afficher(void) {
    cout << this->nom << " : " << this->conso << " [" << this->tabetat[this->etat] << "]\n";
    cout << "\t-> PRIORITE : " << this->tabprio[this->priorite] << endl;
}

int Zone::getConso(void)
{
    return this->conso;
}


int Zone::getEtat(void)
{
    return this->etat;
}


string Zone::getNom(void)
{
    return this->nom;
}


void Zone::setEtat(int nouvEtat)
{
    if (nouvEtat < 0 || nouvEtat > 2) return;

    this->etat = nouvEtat;
}


char Zone::getPrio (void)
{
    return this->priorite;
}















